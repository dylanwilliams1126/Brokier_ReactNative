
import React from 'react';
import { View, Text, StyleSheet, Button } from 'react-native';
import { createStackNavigator, HeaderTitle } from '@react-navigation/stack';
import BottomTabs from './BottomTabs';
import PropertyDetailScreen from '../screens/properties/PropertyDetailScreen';
//import AuthStackScreen from './AuthStackScreen';
import Loading from '../screens/Loading';
import Modal from '../screens/Modal';


const RootStack = createStackNavigator();

const RootStackScreen = () => {
    // const [isLoading, setIsLoading] = React.useState(true);
    // const [user, setUser] = React.useState(true);

    // React.useEffect(() => {
    //     setTimeout(() => {
    //         setIsLoading(!isLoading);
    //         setUser({});
    //     }, 500);
    // }, []);

    return (
        <RootStack.Navigator
            headerMode="none"
            screenOptions={{ animationEnabled: false }}
            mode="modal"
        >
            {/* {isLoading ? (
                <RootStack.Screen name="Loading" component={Loading} />
            ) : user ? (
                <RootStack.Screen name="BottomTabs" component={BottomTabs} />
            ) : (
                <RootStack.Screen name="AuthStackScreen" component={AuthStackScreen} />
            )}
             */}
            <RootStack.Screen name="BottomTabs" component={BottomTabs} />

            <RootStack.Screen
                name="Modal"
                component={Modal}
                options={{ animationEnabled: true }}
            />
        </RootStack.Navigator>
    );

}




export default RootStackScreen;