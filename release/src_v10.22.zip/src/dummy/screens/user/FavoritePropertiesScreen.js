import React from 'react';
import { Button, View, Text, StyleSheet } from 'react-native';

const FavoritePropertiesScreen = props => {
    return (
        <View style={styles.text}>
            <Text>Favorite Properties</Text>
        </View>
    );
};


export const screenOptions = navData => {
    return {
        title: 'Favs',

    };
};

const styles = StyleSheet.create({
    
    text:{
        flex: 1, justifyContent: 'center', alignItems: 'center'

    },
    
    image: {
      width: '100%',
      height: 300
    }
})

export default FavoritePropertiesScreen;