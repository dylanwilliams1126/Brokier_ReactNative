import React from 'react';
import { Button, View, Text } from 'react-native';

const FavoriteCommunitiesScreen = props => {
    return (
        <View>
            <Text>Favorite Communities</Text>
        </View>
    );
};


export const screenOptions = navData => {
    return {
        title: ' Favorite Communities',

    };
};

export default FavoriteCommunitiesScreen;