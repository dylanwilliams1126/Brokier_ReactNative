import React from "react";
import { Platform, StatusBar, StyleSheet, View, Text, Image, TouchableOpacity } from "react-native";

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import Card from '../Card/Card';
import { isEmpty } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

const PropertyProfile = ({ propertyProfile }) => {
  return (
    <Card style={styles.profile}>
      <Image
        style={{ width: 100, height: 100, borderRadius: 50 }}
        source={images.avatar}
      />
      <Text style={{ fontSize: 18, marginTop: 10 }}>Why Work With John Doer</Text>
      <View style={{ width: '90%', height: 220, marginTop: 10 }}>
        <Text style={{ fontSize: 12, fontWeight: 'bold' }}>Listing Service offerings:</Text>
        <Text style={{ fontSize: 12 }}>1% full service listings with free staging consultation, 3D virtual Tours</Text>
        <Text style={{ marginTop: 10, fontSize: 12, fontWeight: 'bold' }}>Buyer Service offerings:</Text>
        <Text style={{ fontSize: 12 }}>Offers 50% of agents commission as cash back</Text>
        <Text style={{ marginTop: 10, fontSize: 12, fontWeight: 'bold' }}>Area of specialty:</Text>
        <Text style={{ fontSize: 12 }}>Chesterfield and Surounding areas</Text>
        <Text style={{ marginTop: 10, fontSize: 12, fontWeight: 'bold' }}>Awards and Achievements:</Text>
        <Text style={{ fontSize: 12 }}>#1 agent in remax office 2017, 2018</Text>
      </View>
      <View style={{ width: '60%', flexDirection: 'row', justifyContent: 'space-around' }}>
        <TouchableOpacity style={styles.button}>
          <Icon name="local-phone" type="material" size={30} />
        </TouchableOpacity>
        <TouchableOpacity style={[styles.button, { borderWidth: 0 }]}>
          <Icon name="earth" type="antdesign" size={30} />
        </TouchableOpacity>
        <TouchableOpacity>
          <Image
            style={{ width: 40, height: 40 }}
            source={icons.instagram}
          />
        </TouchableOpacity>
      </View>
    </Card>
  );
};

const styles = StyleSheet.create({
  profile: {
    alignItems: "center",
    width: "100%",
    padding: 20
  },
  button: {
    justifyContent: 'center',
    alignItems: 'center',
    width: 40,
    height: 40,
    borderRadius: 5,
    borderWidth: 0.5,
    borderColor: colors.GREY.SECONDARY
  }
});

export default PropertyProfile;
