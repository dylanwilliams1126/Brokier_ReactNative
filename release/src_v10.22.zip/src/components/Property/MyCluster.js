import React from "react";
import { Platform, StatusBar, StyleSheet, View, Text } from "react-native";

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import { isEmpty, isCurrency } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

const MyCluster = (props) => {
  const { count, forSale, forRent, sold, rented } = props;
  return (
    <View style={[styles.clusterMarker, {
      backgroundColor: (forSale && !sold) ? '#549E6550' : (!forSale && sold) ? '#E4575750' : (forRent && !rented) ? '#4E9EE950' : (!forRent && rented) ? '#FF990050' : (forSale && sold) ? '#549E6550' : (forRent && rented) ? '#4E9EE950' : null
    }, {
      width: count > 10000 ? 60 : count > 1000 ? 50 : count > 100 ? 45 : 40,
      height: count > 10000 ? 60 : count > 1000 ? 50 : count > 100 ? 45 : 40,
      borderRadius: count > 10000 ? 30 : count > 1000 ? 25 : count > 100 ? 23 : 20
    }]}>
      <View style={[styles.clusterMarker, {
        backgroundColor: (forSale && !sold) ? '#549E65' : (!forSale && sold) ? '#E45757' : (forRent && !rented) ? '#4E9EE9' : (!forRent && rented) ? '#FF9900' : (forSale && sold) ? '#549E65' : (forRent && rented) ? '#4E9EE9' : null
      }, {
        width: count > 10000 ? 52 : count > 1000 ? 42 : count > 100 ? 38 : 32, 
        height: count > 10000 ? 52 : count > 1000 ? 42 : count > 100 ? 38 : 32, 
        borderRadius: count > 10000 ? 26 : count > 1000 ? 21 : count > 100 ? 19 : 16
      }]}>
        <Text style={{ fontSize: 11, fontWeight: 'bold', color: colors.WHITE }}>{count}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  clusterMarker: {
    justifyContent: "center",
    alignItems: "center",
  },
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#549E6550'
  },
  cluster: {
    justifyContent: 'center',
    alignItems: 'center',
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#549E65'
  },
});

export default MyCluster;
