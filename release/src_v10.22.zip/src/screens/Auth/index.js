import React, { Component } from "react";
import { Platform, StatusBar, StyleSheet, View, Text } from "react-native";
import { AnimatedCircularProgress } from 'react-native-circular-progress';

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import { connect } from "react-redux";
import { setUser } from "@modules/redux/auth/actions";
import { Loading } from "@components";
import { isEmpty } from "@utils/functions";
import configs from "@constants/configs";
import { ListingsService } from "@modules/services";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";
import { initial } from "lodash";

class Splash extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      progress: 0,
    };
    this.init();
  }
  async init(){
    await ListingsService.getListingsAll().then((listings)=>{
      global.listings = listings;
      this.props.navigation.navigate('App');
    });
  }


  render() {
    return (
      <View style={styles.container}>
        <StatusBar hidden />
        <AnimatedCircularProgress
          size={100}
          width={2}
          fill={this.state.progress}
          tintColor={colors.BLUE.DEFAULT}
          backgroundColor={colors.WHITE} />
        <Text style={{ marginTop: -65, fontSize: 25, color: colors.WHITE }}>{parseFloat(this.state.progress).toFixed(0)}<Text>%</Text></Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#D35400'
  },
});

export default connect(undefined, undefined)(Splash);
