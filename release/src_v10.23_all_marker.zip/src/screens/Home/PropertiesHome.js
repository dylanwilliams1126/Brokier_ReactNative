import React, { Component } from "react";
import { Platform, StatusBar, StyleSheet, View, TouchableOpacity, Text, Share } from "react-native";
import MapView, { Marker, PROVIDER_GOOGLE, PROVIDER_DEFAULT } from "react-native-maps";
import { ClusterMap } from 'react-native-cluster-map';
import Grid from 'react-native-infinite-scroll-grid';
import * as Location from 'expo-location';
import * as Permissions from 'expo-permissions';

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import { connect } from "react-redux";
import { setTab } from "@modules/redux/auth/actions";
import { Loading, Header, MyCluster, PropertyFilter, PropertySort, PropertyMarker, PropertyItem } from "@components";
import { MapStore } from '@modules/stores';
import { ListingsService } from "@modules/services";
import { isEmpty, isNumber } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import firebase from '@utils/firebase';
import i18n from "@utils/i18n";

class PropertiesHome extends Component {

  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      tab: true,

      view: (global.filters.type == 'Sale' || global.filters.lastStatus == 'Sld') ? true : false,
      forSale: global.filters.type == 'Sale' ? true : false,
      sold: global.filters.lastStatus == 'Sld' ? true : false,
      forRent: global.filters.type == 'Lease' ? true : false,
      rented: global.filters.lastStatus == 'Lsd' ? true : false,
      filter: false,
      badge: global.badge,

      sort: false,
      isLoading: false,
      loadingMore: false,
      refreshing: false,
      offset: 0,

      mapType: 'standard',
      region: {
        latitude: global.region.latitude,
        longitude: global.region.longitude,
        latitudeDelta: global.region.latitudeDelta,
        longitudeDelta: global.region.longitudeDelta
      },
      listings: [],
      listings2: [],
      detail: false,
      details: [],
    };
    this.props.setTab(true);
  }

  onTab() {
    if (this.state.tab) {
      this.props.setTab(true);
      global.marker = false;
      this.setState({ tab: false }, () => {
        this.loadData(global.filters, true, 0);
      })
    } else {
      this.setState({ tab: true }, () => {
        this.onRegionChangeComplete(global.region);
      })
    }
  }

  onRegionChangeComplete(region) {
    global.region = region;
    this.setState({ loading: true, region }, () => this.onStatus(global.filters));
  }

  async onAppleFilters(filters) {
    global.badge = await MapStore.getBadge(filters);
    this.setState({ listings: [], details: [], loading: true, badge: global.badge }, () => {
      this.state.tab ? this.onStatus(filters) : this.loadData(filters, true, 0);
    });
  }

  async onStatus(filters) {
    filters.type = this.state.view ? this.state.forSale ? "Sale" : null : this.state.forRent ? "Lease" : null;
    filters.lastStatus = this.state.view ? this.state.sold ? "Sld" : null : this.state.rented ? "Lsd" : null;
    global.filters = filters;
    this.setState({ listings: await MapStore.getMarkers(global.listings.filter(async (listing) => await MapStore.getListing(listing))), filter: false, loading: false });
  }

  async loadData(filters, refresh, offset) {
    if (this.state.isLoading) return;

    if (refresh) {
      this.setState({ listings2: [], refreshing: true });
    } else {
      this.setState({ loadingMore: true });
    }

    try {
      this.setState({ isLoading: true });
      filters.type = this.state.view ? this.state.forSale ? "Sale" : null : this.state.forRent ? "Lease" : null;
      filters.lastStatus = this.state.view ? this.state.sold ? "Sld" : null : this.state.rented ? "Lsd" : null;
      global.filters = filters;
      var listings = await ListingsService.getListingsList(offset);
      this.setState({ listings2: refresh ? listings : [...this.state.listings2, ...listings], loadingMore: false, offset: offset + 1, filter: false });
    } catch (error) {
      console.log(error);
    } finally {
      this.setState({ isLoading: false, loadingMore: false, refreshing: false, filter: false });
    }
  }

  async onDetail(mlsNumber) {
    var listing = await ListingsService.getListingDetail(mlsNumber);
    this.props.navigation.navigate('PropertiesDetail', { listing });
  }

  onView() {
    this.setState({ view: !this.state.view }, () => {
      this.state.view && this.setState({ loading: true, forSale: true, sold: false, forRent: false, rented: false }, () => {
        this.state.tab ? this.onStatus(global.filters) : this.loadData(global.filters, true, 0);
      });
      !this.state.view && this.setState({ loading: true, forSale: false, sold: false, forRent: true, rented: false }, () => {
        this.state.tab ? this.onStatus(global.filters) : this.loadData(global.filters, true, 0);
      });
    });
  }

  onForSale() {
    if (this.state.forSale && !this.state.sold) {
      return;
    } else {
      this.setState({ loading: true, forSale: !this.state.forSale }, () => {
        this.onStatus(global.filters);
      });
    }
  }
  onForRent() {
    if (this.state.forRent && !this.state.rented) {
      return;
    } else {
      this.setState({ loading: true, forRent: !this.state.forRent }, () => {
        this.onStatus(global.filters);
      });
    }
  }
  onSold() {
    if (!this.state.forSale && this.state.sold) {
      return;
    } else {
      this.setState({ loading: true, sold: !this.state.sold }, () => {
        this.onStatus(global.filters);
      });
    }
  }
  onRented() {
    if (!this.state.forRent && this.state.rented) {
      return;
    } else {
      this.setState({ loading: true, rented: !this.state.rented }, () => {
        this.onStatus(global.filters);
      });
    }
  }

  onMap() {
    setTimeout(() => {
      if (!global.marker) {
        this.props.setTab(true);
        this.setState({ details: [] });
      }
      global.marker = false;
    }, 100)
  }

  async onMarker() {
    if (global.region.latitudeDelta < 0.01) {
      global.marker = true;
      this.props.setTab(false);
      this.setState({ details: global.details });
    } else {
      global.region = {
        latitude: global.details[0].latitude,
        latitudeDelta: global.region.latitudeDelta / 3,
        longitude: global.details[0].longitude,
        longitudeDelta: global.region.longitudeDelta / 3
      }
      this.mapRef.animateToRegion(global.region, 100);
    }
  }

  async onCurrentPosition() {
    let { status } = await Permissions.askAsync(Permissions.LOCATION);
    if (status !== 'granted') {
      alert('Permission to access location was denied');
    }
    let location = await Location.getCurrentPositionAsync({});
    if (location) {
      global.region = {
        latitude: location.coords.latitude,
        latitudeDelta: 0.001,
        longitude: location.coords.longitude,
        longitudeDelta: 0.001
      }
      this.mapRef.animateToRegion(global.region, 100);
    }
  }

  onShare() {
    Share.share({
      title: "Title",
      url: "https:"
    })
  };

  render() {
    return (
      <View style={styles.container}>
        <Header style={{ paddingLeft: 10, paddingRight: 10 }}>
          <View style={styles.header}>
            <TouchableOpacity style={styles.searchBar} onPress={() => this.props.navigation.navigate('PropertiesSearch')}>
              <View style={styles.searchIcon}><Icon name="search" type="material" size={25} /></View>
              <View style={{ marginLeft: 5 }}><Text>{"Search MLS number, Address, City"}</Text></View>
            </TouchableOpacity>
            <View style={styles.listButton}>
              <TouchableOpacity onPress={async () => this.onTab()}>
                <Text>{this.state.tab ? 'List' : 'Map'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Header>

        <View style={styles.container}>
          {this.state.tab ?
            <View style={[styles.statusBar, { justifyContent: "space-between" }]}>
              {this.state.view ?
                <TouchableOpacity style={this.state.forSale ? styles.greenButton : styles.whiteButton} onPress={() => this.onForSale()}>
                  <Text style={this.state.forSale ? { fontSize: 12, fontWeight: "500", color: colors.WHITE } : { fontSize: 12, color: colors.BLACK }}>FOR SALE</Text>
                </TouchableOpacity> :
                <TouchableOpacity style={this.state.forRent ? styles.blueButton : styles.whiteButton} onPress={() => this.onForRent()}>
                  <Text style={this.state.forRent ? { fontSize: 12, fontWeight: "500", color: colors.WHITE } : { fontSize: 12, color: colors.BLACK }}>FOR RENT</Text>
                </TouchableOpacity>}
              {this.state.view ?
                <TouchableOpacity style={this.state.sold ? styles.redButton : styles.white2Button} onPress={() => this.onSold()}>
                  <Text style={this.state.sold ? { fontSize: 12, fontWeight: "500", color: colors.WHITE } : { fontSize: 12, color: colors.BLACK }}>SOLD</Text>
                </TouchableOpacity> :
                <TouchableOpacity style={this.state.rented ? styles.orangeButton : styles.white2Button} onPress={() => this.onRented()}>
                  <Text style={this.state.rented ? { fontSize: 12, fontWeight: "500", color: colors.WHITE } : { fontSize: 12, color: colors.BLACK }}>RENTED</Text>
                </TouchableOpacity>}
              <TouchableOpacity style={styles.filters} onPress={() => this.setState({ filter: true })}>
                <Icon name="keyboard-arrow-down" type="material" size={20} />
                <Text style={{ fontSize: 12, color: colors.BLACK }}>Filters</Text>
                {this.state.badge > 0 ? <View style={styles.badge}><Text style={styles.badgeText}>{this.state.badge}</Text></View> : <View style={{ width: 10 }} />}
              </TouchableOpacity>
              <TouchableOpacity style={styles.save}>
                <Text style={{ fontSize: 12, color: colors.BLACK }}>Save Search</Text>
                <Icon name="heart" type="material-community" size={15} />
              </TouchableOpacity>
            </View> :
            <View style={[styles.statusBar, { justifyContent: "space-around" }]}>
              <TouchableOpacity style={styles.sort} onPress={() => this.setState({ sort: true })}>
                <Icon name="keyboard-arrow-down" type="material" size={20} />
                <Text style={{ fontSize: 12, color: colors.BLACK }}>Sort</Text>
                <Icon name="sort" type="material-community" size={15} />
              </TouchableOpacity>
              <TouchableOpacity style={styles.filters} onPress={() => this.setState({ filter: true })}>
                <Icon name="keyboard-arrow-down" type="material" size={20} />
                <Text style={{ fontSize: 12, color: colors.BLACK }}>Filters</Text>
                {this.state.badge > 0 ? <View style={styles.badge}><Text style={styles.badgeText}>{this.state.badge}</Text></View> : <View style={{ width: 10 }} />}
              </TouchableOpacity>
              <TouchableOpacity style={styles.save}>
                <Text style={{ fontSize: 12, color: colors.BLACK }}>Save Search</Text>
                <Icon name="heart" type="material-community" size={15} />
              </TouchableOpacity>
            </View>
          }
          {this.state.tab ?
            // <MapView
            //   ref={map => { this.mapRef = map }}
            //   provider={Platform.OS === 'android' ? PROVIDER_GOOGLE : PROVIDER_DEFAULT}
            //   mapType={this.state.mapType}
            //   showsUserLocation={true}
            //   showsPointsOfInterest={true}
            //   minZoomLevel={5}
            //   initialRegion={this.state.region}
            //   style={{ width: wp("100%"), height: hp('100%') - 120 }}
            //   onPress={() => this.onMap()}
            //   onMarkerPress={() => this.onMarker()}
            //   onRegionChangeComplete={this.onRegionChangeComplete.bind(this)}
            // >
            //   {
            //     (!this.state.loading && !isEmpty(this.state.listings)) && this.state.listings.map((item, key) => (
            //       item[0].count > 1 ?
            //         <Marker key={key} coordinate={{ latitude: parseFloat(item[0].latitude), longitude: parseFloat(item[0].longitude) }} onPress={() => { global.details = item }}>
            //           <View style={[styles.clusterMarker, !this.state.loading && {
            //             backgroundColor: (this.state.forSale && !this.state.sold) ? '#549E6550' : (!this.state.forSale && this.state.sold) ? '#E4575750' : (this.state.forRent && !this.state.rented) ? '#4E9EE950' : (!this.state.forRent && this.state.rented) ? '#FF990050' : (this.state.forSale && this.state.sold) ? '#549E6550' : (this.state.forRent && this.state.rented) ? '#4E9EE950' : null
            //           }, {
            //             width: global.region.latitudeDelta > 0.15 ? 58 : 42, height: global.region.latitudeDelta > 0.15 ? 58 : 42, borderRadius: global.region.latitudeDelta > 0.15 ? 29 : 21
            //           }]}>
            //             <View style={[styles.clusterMarker, !this.state.loading && {
            //               backgroundColor: (this.state.forSale && !this.state.sold) ? '#549E65' : (!this.state.forSale && this.state.sold) ? '#E45757' : (this.state.forRent && !this.state.rented) ? '#4E9EE9' : (!this.state.forRent && this.state.rented) ? '#FF9900' : (this.state.forSale && this.state.sold) ? '#549E65' : (this.state.forRent && this.state.rented) ? '#4E9EE9' : null
            //             }, {
            //               width: global.region.latitudeDelta > 0.15 ? 50 : 34, height: global.region.latitudeDelta > 0.15 ? 50 : 34, borderRadius: global.region.latitudeDelta > 0.15 ? 25 : 17
            //             }]}>
            //               <Text style={{ fontSize: 11, fontWeight: 'bold', color: colors.WHITE }}>{item[0].count}</Text>
            //             </View>
            //           </View>
            //         </Marker>
            //         :
            //         <Marker key={key} coordinate={{ latitude: parseFloat(item[0].latitude), longitude: parseFloat(item[0].longitude) }} onPress={() => { global.details = item }}>
            //           <View style={{ alignItems: 'center' }}>
            //             <View style={[styles.customMarker, !this.state.loading && {
            //               backgroundColor: !isEmpty(this.state.details) && (item[0].mlsNumber === global.details[0].mlsNumber) ? '#7864A3' : (this.state.forSale && !this.state.sold) ? '#549E65' : (!this.state.forSale && this.state.sold) ? '#E45757' : (this.state.forRent && !this.state.rented) ? '#4E9EE9' : (!this.state.forRent && this.state.rented) ? '#FF9900' : (this.state.forSale && this.state.sold && item[0].lastStatus != 'Sld') ? '#549E65' : (this.state.forSale && this.state.sold && item[0].lastStatus == 'Sld') ? '#E45757' : (this.state.forRent && this.state.rented && item[0].lastStatus != 'Lsd') ? '#4E9EE9' : (this.state.forRent && this.state.rented && item[0].lastStatus == 'Lsd') ? '#FF9900' : null,
            //               borderColor: !isEmpty(this.state.details) && (item[0].mlsNumber === global.details[0].mlsNumber) ? '#615282' : (this.state.forSale && !this.state.sold) ? '#4d8a5b' : (!this.state.forSale && this.state.sold) ? '#cc5252' : (this.state.forRent && !this.state.rented) ? '#4688c7' : (!this.state.forRent && this.state.rented) ? '#d6860f' : (this.state.forSale && this.state.sold && item[0].lastStatus != 'Sld') ? '#4d8a5b' : (this.state.forSale && this.state.sold && item[0].lastStatus == 'Sld') ? '#cc5252' : (this.state.forRent && this.state.rented && item[0].lastStatus != 'Lsd') ? '#4688c7' : (this.state.forRent && this.state.rented && item[0].lastStatus == 'Lsd') ? '#d6860f' : null,
            //             }]}>
            //               <Text style={{ fontWeight: 'bold', color: colors.WHITE }}>{item.length > 1 ? `${item.length} Units` : isNumber(parseFloat(item[0].listPrice))}</Text>
            //             </View>
            //             <View style={[styles.triangle, !this.state.loading && {
            //               borderBottomColor: !isEmpty(this.state.details) && (item[0].mlsNumber === global.details[0].mlsNumber) ? '#7864A3' : (this.state.forSale && !this.state.sold) ? '#549E65' : (!this.state.forSale && this.state.sold) ? '#E45757' : (this.state.forRent && !this.state.rented) ? '#4E9EE9' : (!this.state.forRent && this.state.rented) ? '#FF9900' : (this.state.forSale && this.state.sold && item[0].lastStatus != 'Sld') ? '#549E65' : (this.state.forSale && this.state.sold && item[0].lastStatus == 'Sld') ? '#E45757' : (this.state.forRent && this.state.rented && item[0].lastStatus != 'Lsd') ? '#4E9EE9' : (this.state.forRent && this.state.rented && item[0].lastStatus == 'Lsd') ? '#FF9900' : null,
            //             }]} />
            //           </View>
            //         </Marker>
            //     ))
            //   }
            // </MapView> :
            <ClusterMap
              region={this.state.region}
              mapType={this.state.mapType}
              provider={Platform.OS === 'android' ? PROVIDER_GOOGLE : PROVIDER_DEFAULT}
              // initialRegion={this.state.region}
              // clusterColor="#549E65"
              style={{ width: wp("100%"), height: hp('100%') - 120 }}
              onPress={() => this.onMap()}
              onMarkerPress={() => this.onMarker()}
              renderClusterMarker={({ pointCount, clusterId }) => <MyCluster count={pointCount} forSale={this.state.forSale} forRent={this.state.forRent} sold={this.state.sold} rented={this.state.rented} />}
              onRegionChangeComplete={this.onRegionChangeComplete.bind(this)}
            >
              {!isEmpty(this.state.listings) && this.state.listings.map((item, key) => (
                <Marker key={key} coordinate={{ latitude: parseFloat(item[0].latitude), longitude: parseFloat(item[0].longitude) }} onPress={() => { global.details = item }}>
                  <View style={{ alignItems: 'center' }}>
                    <View style={[styles.customMarker, { backgroundColor: !isEmpty(this.state.details) && (item[0].mlsNumber === global.details[0].mlsNumber) ? colors.RED.PRIMARY : colors.GREEN.PRIMARY }]}>
                      <Text style={{ fontWeight: 'bold', color: colors.WHITE }}>{item.length > 1 ? `${item.length} Units` : isNumber(parseFloat(item[0].listPrice))}</Text>
                    </View>
                    <View style={[styles.triangle, { borderBottomColor: !isEmpty(this.state.details) && (item[0].mlsNumber === global.details[0].mlsNumber) ? colors.RED.PRIMARY : colors.GREEN.PRIMARY }]} />
                  </View>
                </Marker>
              ))}
            </ClusterMap> :
            !isEmpty(this.state.listings2) &&
            <Grid
              data={this.state.listings2}
              // keyExtractor={(listing) => listing.mlsNumber}
              renderItem={(listing) => (
                <View style={{ paddingBottom: 5 }}>
                  <PropertyItem
                    key={listing.item.mlsNumber}
                    listing={listing.item}
                    onPress={() => this.onDetail(listing.item.mlsNumber)}
                    onLike={() => alert('Like')}
                    onShare={() => alert('Share')}
                    onComment={() => this.props.navigation.push("Auth")}
                  />
                </View>
              )}
              refreshing={this.state.refreshing}
              loadingMore={this.state.loadingMore}
              onRefresh={() => this.loadData(global.filters, true, 0)}
              onEndReached={() => this.loadData(global.filters, false, this.state.offset)}
            />
          }
        </View>

        {this.state.tab && <TouchableOpacity style={styles.locationButton} onPress={() => this.state.mapType === 'standard' ? this.setState({ mapType: 'satellite' }) : this.setState({ mapType: 'standard' })}>
          <Icon name={this.state.mapType === 'standard' ? "earth" : "map-outline"} type="material-community" size={20} color={colors.BLACK} />
        </TouchableOpacity>}
        {this.state.tab && <TouchableOpacity style={styles.drawButton}>
          <Icon name="vector-polyline" type="material-community" size={20} color={colors.BLACK} />
        </TouchableOpacity>}
        {this.state.tab && <TouchableOpacity style={styles.satButton}>
          <Icon name="location-searching" type="material" size={20} color={colors.BLACK} onPress={() => this.onCurrentPosition()} />
        </TouchableOpacity>}
        {this.state.tab && <TouchableOpacity style={styles.viewButton} onPress={() => this.onView()}>
          <Text>{this.state.view ? 'View Listings for Rent' : 'View Listings for Sale'}</Text>
        </TouchableOpacity>}
        <Loading loading={this.state.loading} />

        {!isEmpty(this.state.details) && (
          <PropertyMarker
            listings={this.state.details}
            navigation={this.props.navigation}
            onLogin={() => this.props.navigation.push("Auth")}
            onLike={() => alert("Like")}
            onShare={() => this.onShare()} />
        )}
        <PropertyFilter
          visible={this.state.filter}
          view={this.state.view}
          onView={() => this.onView()}
          onAppleFilters={(filters) => this.onAppleFilters(filters)}
          onClose={() => this.setState({ filter: false })}
        />
        <PropertySort visible={this.state.sort} onClose={() => this.setState({ sort: false })} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 10,
    padding: 2,
    width: "100%",
    height: 35,
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    padding: 2,
    width: wp("100%") - 90,
    height: 30,
    borderWidth: 0,
    borderRadius: 5,
    backgroundColor: colors.GREY.SECONDARY
  },
  searchIcon: {
    justifyContent: "center",
    alignItems: "center",
    width: 26,
    height: 26,
    backgroundColor: colors.WHITE,
    borderRadius: 5,
  },
  inputContainerStyle: {
    height: 30,
    borderBottomWidth: 0,
  },
  textInputStyle: {
    height: 30,
    width: wp("100%") - 120,
  },
  inputTextStyle: {
    height: 30,
    fontSize: 14,
  },
  listButton: {
    justifyContent: "center",
    alignItems: "center",
    marginLeft: 10,
    width: 50,
    height: 30,
    borderWidth: 0,
    borderRadius: 5,
    backgroundColor: colors.GREY.PRIMARY,
  },
  statusBar: {
    flexDirection: "row",
    alignItems: "center",
    padding: 10,
    width: wp("100%"),
    height: 40,
    backgroundColor: colors.GREY.SECONDARY,
  },
  greenButton: {
    justifyContent: "center",
    alignItems: "center",
    width: 80,
    height: 20,
    borderRadius: 5,
    backgroundColor: colors.GREEN.PRIMARY,
  },
  blueButton: {
    justifyContent: "center",
    alignItems: "center",
    width: 80,
    height: 20,
    borderRadius: 5,
    backgroundColor: '#4E9EE9',
  },
  orangeButton: {
    justifyContent: "center",
    alignItems: "center",
    width: 70,
    height: 20,
    borderRadius: 5,
    backgroundColor: '#FF9900',
  },
  whiteButton: {
    justifyContent: "center",
    alignItems: "center",
    width: 80,
    height: 20,
    borderRadius: 5,
    borderWidth: 0.5,
    backgroundColor: colors.WHITE,
  },
  redButton: {
    justifyContent: "center",
    alignItems: "center",
    width: 70,
    height: 20,
    borderRadius: 5,
    backgroundColor: colors.RED.PRIMARY,
  },
  white2Button: {
    justifyContent: "center",
    alignItems: "center",
    width: 70,
    height: 20,
    borderRadius: 5,
    borderWidth: 0.5,
    backgroundColor: colors.WHITE,
  },
  sort: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: 85,
    height: 20,
    paddingLeft: 5,
    paddingRight: 5,
    borderWidth: 0.5,
    borderRadius: 5,
    backgroundColor: colors.WHITE,
  },
  filters: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: 90,
    height: 20,
    paddingLeft: 5,
    paddingRight: 5,
    borderWidth: 0.5,
    borderRadius: 5,
    backgroundColor: colors.WHITE,
  },
  badge: {
    backgroundColor: colors.RED.PRIMARY,
    borderRadius: 7,
    width: 14,
    height: 14,
    justifyContent: "center",
    alignItems: "center",
  },
  badgeText: {
    color: "white",
    fontSize: 10,
    fontWeight: "bold",
  },
  save: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: 100,
    height: 20,
    paddingLeft: 5,
    paddingRight: 5,
    borderWidth: 0.5,
    borderRadius: 5,
    backgroundColor: colors.WHITE,
  },
  touch: {
    width: "100%",
    height: "100%",
    justifyContent: "center",
    alignItems: "center",
  },
  locationButton: {
    position: "absolute",
    bottom: 100,
    right: 20,
    justifyContent: "center",
    alignItems: "center",
    width: 35,
    height: 35,
    backgroundColor: colors.WHITE,
    borderRadius: 5,
    shadowColor: colors.BLACK,
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1,
    elevation: 1,
  },
  drawButton: {
    position: "absolute",
    bottom: 60,
    right: 20,
    justifyContent: "center",
    alignItems: "center",
    width: 35,
    height: 35,
    backgroundColor: colors.WHITE,
    borderRadius: 5,
    shadowColor: colors.BLACK,
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1,
    elevation: 1,
  },
  satButton: {
    position: "absolute",
    bottom: 20,
    right: 20,
    justifyContent: "center",
    alignItems: "center",
    width: 35,
    height: 35,
    backgroundColor: colors.WHITE,
    borderRadius: 5,
    shadowColor: colors.BLACK,
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1,
    elevation: 1,
  },
  viewButton: {
    position: "absolute",
    bottom: 20,
    left: wp('100%') / 2 - 80,
    justifyContent: "center",
    alignItems: "center",
    width: 160,
    height: 25,
    backgroundColor: colors.WHITE,
    borderRadius: 5,
    shadowColor: colors.BLACK,
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1,
    elevation: 1,
  },
  customMarker: {
    justifyContent: 'center',
    alignItems: 'center',
    paddingLeft: 5,
    paddingRight: 5,
    height: 20,
    borderRadius: 4,
    borderWidth: 2
  },
  triangle: {
    transform: [
      { rotate: '180deg' }
    ],
    width: 0,
    height: 0,
    backgroundColor: 'transparent',
    borderStyle: 'solid',
    borderLeftWidth: 6,
    borderRightWidth: 6,
    borderBottomWidth: 6,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderBottomColor: '#549E65'
  },
  clusterMarker: {
    justifyContent: "center",
    alignItems: "center",
  },
  loading: {
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: wp('50%') - 20,
    marginBottom: 10,
    width: 40,
    height: 40,
    borderRadius: 5,
    backgroundColor: '#00000080',
    shadowColor: colors.BLACK,
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1,
    elevation: 1,
  }
});

const mapStateToProps = state => {
  return {
    logged: state.auth.logged
  }
}

const mapDispatchToProps = dispatch => {
  return {
    setTab: (data) => {
      dispatch(setTab(data))
    },
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(PropertiesHome);
