import React, { Component } from "react";
import { Platform, StatusBar, StyleSheet, View, Text, TouchableOpacity } from "react-native";
import * as Facebook from 'expo-facebook';
import * as Google from 'expo-google-app-auth';

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import { connect } from "react-redux";
import { setUser } from "@modules/redux/auth/actions";
import { Loading, TextInput, NormalButton } from "@components";
import { isEmpty, validateEmail } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import firebase from '@utils/firebase';
import i18n from "@utils/i18n";

class SignIn extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      email: "",
      password: ""
    };
  }

  async EPLogin() {
    if (this.state.email && this.state.password && validateEmail) {
      await firebase
        .auth()
        .signInWithEmailAndPassword(this.state.email, this.state.password)
        .then(() => {
          // this.props.navigation.navigate('Profile')
          alert("OK")
        })
        .catch(error => {
          console.log(error.message)
        })

    }
  }

  async FBLogin() {
    try {
      await Facebook.initializeAsync('220105416074930');
      const result = await Facebook.logInWithReadPermissionsAsync({
        permissions: ['public_profile', "email"],
      });
      alert(JSON.stringify(result));
    } catch (e) {
      return { error: true }
    }
  }

  async GGLogin() {
    try {
      const result = await Google.logInAsync({
        androidClientId: configs.google_auth_config.androidClientId,
        iosClientId: configs.google_auth_config.iosClientId,
        scopes: ['profile', 'email']
      });

      if (result.type === 'success') {
        alert(JSON.stringify(result))
      } else {
        return { cancelled: true }
      }
    } catch (e) {
      return { error: true };
    }
  }

  render() {
    const { email, password } = this.state;
    return (
      <View style={styles.container}>
        <StatusBar hidden />
        <Loading loading={this.state.loading} />
        <View style={{ marginTop: 50, width: wp("100%"), alignItems: "flex-start", paddingLeft: 20 }}>
          <TouchableOpacity onPress={() => this.props.navigation.pop()}><Icon name="close" type="ant-design" size={40} /></TouchableOpacity>
        </View>
        <Text style={{ marginTop: 50, fontSize: 34, fontWeight: 'bold' }}> Sign In</Text>
        <TextInput
          title="Email" iconName="email" iconType="fontisto" iconSize={20}
          value={email} secureTextEntry={false} autoCapitalize="none"
          onChangeText={(email) => this.setState({ email })}
        />
        <TextInput
          title="Password" iconName="lock" iconType="entypo" iconSize={20}
          value={password} secureTextEntry={true}
          onChangeText={(password) => this.setState({ password })}
        />
        <NormalButton
          width={wp("90%")}
          height={40}
          color="#0073E4"
          text="Sign In"
          textColor={colors.WHITE}
          onPress={() => this.EPLogin()}
        />
        <TouchableOpacity style={{ marginTop: 20 }}><Text style={{ color: "#0072DC", textDecorationLine: "underline" }}>Forgot Password?</Text></TouchableOpacity>
        <NormalButton
          width={wp("90%")}
          height={40}
          color="#C4DAF0"
          text="Sign in Facebook"
          textColor="#0072DC"
          onPress={() => this.FBLogin()}
        />
        <NormalButton
          width={wp("90%")}
          height={40}
          color="#F0C4C4"
          text="Sign in Google"
          textColor="#EA5050"
          onPress={() => this.GGLogin()}
        />
        <View style={{ flexDirection: "row", marginTop: 5 }}>
          <Text style={{ fontSize: 12 }}>Don't you have account? </Text>
          <TouchableOpacity onPress={() => {
            // this.props.navigation.pop();
            this.props.navigation.navigate("SignUp");
          }}><Text style={{ fontSize: 12, color: colors.BLUE.PRIMARY, textDecorationLine: "underline" }}>Sign Up</Text></TouchableOpacity>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#E3E3E3",
    alignItems: 'center'
  },
});

export default connect(undefined, undefined)(SignIn);
