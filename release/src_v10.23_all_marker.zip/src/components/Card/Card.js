import React from "react";
import { Platform, StatusBar, StyleSheet, View, Text } from "react-native";

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import { isEmpty } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

const Card = (props) => {
  return (
    <View key={props.key} style={{ ...styles.card, ...props.style }}>{props.children}</View>
  );
};

const styles = StyleSheet.create({
  card: {
    width: wp("100%"),
    backgroundColor: colors.WHITE,
    borderBottomWidth: 0.3,
    borderBottomColor: colors.GREY.CARDLINE,
  },
});

export default Card;
