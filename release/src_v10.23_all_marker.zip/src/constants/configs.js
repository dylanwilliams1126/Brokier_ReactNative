export default {
    apiURL: "http://brokier.com/api",
    // apiURL: "http://prozim.kwikbookings.com/api",
    resURL: "https:cdn.repliers.io/",

    // google_map_key: 'AIzaSyAU54vgtYyzf4gUDXFALWt5vYTJsnGZraM',
    google_map_key: 'AIzaSyAeJJDLz3XwOJcU7gwzBp0756V5j3d_YqM',

    latitude: 43.640856,
    longitude: -79.387236,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
}