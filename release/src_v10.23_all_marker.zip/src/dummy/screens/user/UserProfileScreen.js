import React from 'react';
import { Button, View, Text, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';


const UserProfileScreen = props => {
    const navigation = useNavigation();
    return (
        <View style={styles.text}>
            <Text>User Profile</Text>
            <Button title="Add Property" onPress={() => { navigation.navigate('AddProperty') }} />
            <Button title="Open Modal" onPress={() => {navigation.navigate('Modal') }} />
            <Button title="Open Alert" onPress={() => alert('todo!')} />
        </View>
    );
};


export const screenOptions = navData => {
    return {
        title: ' Profile',

    };
};

const styles = StyleSheet.create({

    text: {
        flex: 1, justifyContent: 'center', alignItems: 'center'

    },

    image: {
        width: '100%',
        height: 300
    }
})


export default UserProfileScreen;
