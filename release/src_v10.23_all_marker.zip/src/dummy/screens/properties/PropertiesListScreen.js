import React, { Fragment } from 'react';
import { View, FlatList, Text, Button, Image, StyleSheet } from 'react-native';
import { useSelector } from 'react-redux';
import PropertyItem from '../../components/PropertyItem';

const PropertiesListScreen = props => {
    const properties = useSelector(state => state.properties.mlsProperties)
    return (
        <FlatList
            data={properties}
            renderItem={itemData => 
                <PropertyItem 
                    mlsNumber={itemData.item.mlsNumber} 
                    address={itemData.item.address} 
                    listPrice={itemData.item.listPrice} 
                    imageUrl1={itemData.item.imageUrl1}
                    //onSelect={props.navigation.navigate('PropertiesMapScreen')}
                />
            }
            
        />
        
    );
};

export const screenOptions = navData => {
    return {
        title: 'Properties List',

    };
};

const styles = StyleSheet.create({
    
    address:{
        alignItems: 'center',
        padding: 10
    },
    
    image: {
      width: '100%',
      height: 300
    }
})

export default PropertiesListScreen;