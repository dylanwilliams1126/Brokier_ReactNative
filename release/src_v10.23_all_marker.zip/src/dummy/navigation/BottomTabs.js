import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
//import { Ionicons } from '@expo/vector-icons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

//import UserProfileScreen, { screenOptions as UserProfileScreenOptions } from '../screens/user/UserProfileScreen';
import StatsMainScreen, { screenOptions as StatsMainScreenOptions } from '../screens/statistics/StatsMainScreen';
import FinancesMainScreen, { screenOptions as FinancesMainScreenOptions } from '../screens/finance/FinancesMainScreen';

//import {PropertiesMapHeader, FavoritePropertiesHeader, UserProfileHeader} from './TopHeaders';
import PropertiesMapStackScreen from './PropertiesMapStackScreen';
import FavoritePropertiesStackScreen from './FavoritePropertiesStackScreen';
import UserProfileStackScreen from './UserProfileStackScreen';


function IconWithBadge({ name, badgeCount, color, size }) {
    return (
        <View style={{ width: 28, height: 40, marginTop: 20 }}>
            <MaterialCommunityIcons name={name} size={30} color={color} />
            {badgeCount > 0 && (
                <View style={styles.badge}>
                    <Text style={styles.badgeText}>
                        {badgeCount}
                    </Text>
                </View>
            )}
        </View>
    );
}

function FavIconWithBadge(props) {
    // You should pass down the badgeCount in some other ways like React Context API, Redux, MobX or event emitters.
    return <IconWithBadge {...props} badgeCount={3} />;
}


const Tab = createBottomTabNavigator();
const BottomTabs = props => {
    return (
        <Tab.Navigator
            screenOptions={({ route }) => ({
                tabBarIcon: ({ focused, color, size }) => {
                    let iconName;
                    if (route.name === 'PropertiesMap') {
                        return (
                            <IconWithBadge
                                name={
                                    focused
                                        ? 'map-search'
                                        : 'map-search'
                                }
                                size={30}
                                color={color}
                            />
                        );
                    } else if (route.name === 'FavoriteProperties') {
                        return (
                            <FavIconWithBadge
                                name={
                                    focused
                                        ? 'star'
                                        : 'star-outline'
                                }
                                size={30}
                                color={color}
                            />
                        );
                    } else if (route.name === 'FinancesMain') {
                        return (
                            <IconWithBadge
                                name={
                                    focused
                                        ? 'calculator'
                                        : 'calculator'
                                }
                                size={30}
                                color={color}
                            />
                        );
                    } else if (route.name === 'StatsMain') {
                        return (
                            <IconWithBadge
                                name={
                                    focused
                                        ? 'finance'
                                        : 'finance'
                                }
                                size={30}
                                color={color}
                            />
                        );
                    } else if (route.name === 'UserProfile') {
                        return (
                            <FavIconWithBadge
                                name={
                                    focused
                                        ? 'account'
                                        : 'account'
                                }
                                size={30}
                                color={color}
                            />
                        );
                    }

                    // You can return any component that you like here!
                },
            })}
            tabBarOptions={{
                activeTintColor: '#101010'
              }}
        >
            <Tab.Screen
                name="PropertiesMap"
                component={PropertiesMapStackScreen}
                options={{ title: 'search' }}
            />
            <Tab.Screen
                name="FavoriteProperties"
                component={FavoritePropertiesStackScreen}
                options={{ title: 'Fav' }}
            />
            <Tab.Screen
                name="FinancesMain"
                component={FinancesMainScreen}
                options={{ title: 'Mortgage' }}
            />
            <Tab.Screen
                name="StatsMain"
                component={StatsMainScreen}
                options={{ title: 'Stats' }}
            />
            <Tab.Screen
                name="UserProfile"
                component={UserProfileStackScreen}
                options={{ title: 'Profile' }}
            />
            
        </Tab.Navigator>
    );
};

const styles = StyleSheet.create({
    badge: {
        // On React Native < 0.57 overflow outside of parent will not work on Android, see https://git.io/fhLJ8
        position: 'absolute',
        right: -6,
        top: -3,
        backgroundColor: 'red',
        borderRadius: 6,
        width: 12,
        height: 12,
        justifyContent: 'center',
        alignItems: 'center',
    },
    badgeText: {
        color: 'white',
        fontSize: 10,
        fontWeight: 'bold'
    }


})

export default BottomTabs;
