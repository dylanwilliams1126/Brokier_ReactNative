import React from 'react';
import { createStackNavigator, HeaderTitle } from '@react-navigation/stack';
import FavoritePropertiesScreen from '../screens/user/FavoritePropertiesScreen';

const FavoritePropertyStack = createStackNavigator();

const FavoritePropertiesStackScreen = () => {
    return (
        <FavoritePropertyStack.Navigator>
            <FavoritePropertyStack.Screen
                name="Favorites"
                component={FavoritePropertiesScreen}
                options={{ tabBarLabel: 'Favourite Properties' }}
            />
            
        </FavoritePropertyStack.Navigator>
    );
}

export default FavoritePropertiesStackScreen;