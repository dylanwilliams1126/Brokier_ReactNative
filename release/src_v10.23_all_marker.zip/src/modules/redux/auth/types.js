export default {
    SET_USER: 'SET_USER',
    SIGN_OUT: 'SIGN_OUT',
    SET_TAB_VISIBLE: 'SET_TAB_VISIBLE'
}