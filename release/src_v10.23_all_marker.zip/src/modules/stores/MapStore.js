import { isEmpty, isCurrency } from "@utils/functions";

const latitude = 43.640856;
const longitude = -79.387236;
const latitudeDelta = 0.005;
const longitudeDelta = 0.005;

class Store {
  mapState = {
    loading: false,
    tab_visible: false,
    region: {
      latitude: latitude,
      longitude: longitude,
      latitudeDelta: latitudeDelta,
      longitudeDelta: longitudeDelta
    },
    points: {
      NorthEast: {
        latitude: latitude + latitudeDelta / 1.3,
        longitude: longitude + longitudeDelta / 2
      },
      NorthWest: {
        latitude: latitude + latitudeDelta / 1.3,
        longitude: longitude - longitudeDelta / 2
      },
      SouthWest: {
        latitude: latitude - latitudeDelta / 2.4,
        longitude: longitude - longitudeDelta / 2
      },
      SouthEast: {
        latitude: latitude - latitudeDelta / 2.4,
        longitude: longitude + longitudeDelta / 2
      }
    },
    endpoint: 'listings?resultsPerPage=50',
    searchString: "Search MLS number, Address, City",
    view: false,
    forSale: false,
    sold: false,
    forRent: false,
    rented: false,
    markerStatus: false,
  }

  async init() {
    this.mapState = {
      loading: false,
      region: {
        latitude: 43.640856,
        longitude: -79.387236,
        latitudeDelta: 0.05,
        longitudeDelta: 0.05
      },
      points: {
        NorthEast: {
          latitude: latitude + latitudeDelta / 1.3,
          longitude: longitude + longitudeDelta / 2
        },
        NorthWest: {
          latitude: latitude + latitudeDelta / 1.3,
          longitude: longitude - longitudeDelta / 2
        },
        SouthWest: {
          latitude: latitude - latitudeDelta / 2.4,
          longitude: longitude - longitudeDelta / 2
        },
        SouthEast: {
          latitude: latitude - latitudeDelta / 2.4,
          longitude: longitude + longitudeDelta / 2
        }
      },
      endpoint: 'listings?resultsPerPage=50',
      searchString: "Search MLS number, Address, City",
      view: false,
      forSale: false,
      sold: false,
      forRent: false,
      rented: false,
      markerStatus: false,
    }
    this.getListings();
  }

  getListing(listing) {
    let filters = global.filters;
    let flag = true;

    flag &= listing.latitude < (global.region.latitude + global.region.latitudeDelta / 2) && listing.latitude > (global.region.latitude - global.region.latitudeDelta / 2) && listing.longitude < (global.region.longitude + global.region.longitudeDelta / 2) && listing.longitude > (global.region.longitude - global.region.longitudeDelta / 2);

    if (filters.type == "Sale" && filters.lastStatus == "Sld") {
      flag &= (listing.status == "A" && listing.type == "Sale") || (listing.status == "U" && listing.lastStatus == "Sld");
    } else if (filters.type == "Lease" && filters.lastStatus == "Lsd") {
      flag &= (listing.status == "A" && listing.type == "Lease") || (listing.status == "U" && listing.lastStatus == "Lsd");
    } else if (filters.type == "Sale" && filters.lastStatus == null) {
      flag &= (listing.status == "A" && listing.type == "Sale");
    } else if (filters.type == "Lease" && filters.lastStatus == null) {
      flag &= (listing.status == "A" && listing.type == "Lease");
    } else if (filters.type == null && filters.lastStatus == "Sld") {
      flag &= (listing.status == "U" && listing.lastStatus == "Sld");
    } else if (filters.type == null && filters.lastStatus == "Lsd") {
      flag &= (listing.status == "U" && listing.lastStatus == "Lsd");
    }

    flag &= filters.propertyType.allTypes ? true : true;
    flag &= filters.propertyType.detached ? (listing.class == "ResidentialProperty" || listing.details.propertyType == "Detached") : true;
    flag &= filters.propertyType.semiDetached ? listing.propertyType == "Semi-Detached" : true;
    flag &= filters.propertyType.freeholdTown ? listing.propertyType == "Att/Row/Twnhouse" : true;
    flag &= filters.propertyType.condoTown ? (listing.class == "CondoProperty" || listing.propertyType == "Condo Townhouse") : true;
    flag &= filters.propertyType.condoApartment ? listing.propertyType == "Condo Apt" : true;
    flag &= filters.propertyType.duplex ? true : true;
    flag &= filters.propertyType.multiFamily ? listing.propertyType == "Att/Row/Twnhouse" : true;
    flag &= filters.propertyType.land ? listing.propertyType == "Land" || listing.propertyType == "Vacant Land" : true;
    
    flag &= filters.price.minPrice == 50000 && filters.price.maxPrice == 5000000 ? true : (filters.price.minPrice <= parseFloat(listing.listPrice)) && (parseFloat(listing.listPrice) <= filters.price.maxPrice);
    flag &= filters.daysOnMarket == 0 ? true : filters.daysOnMarket >= parseInt((Date.now() - Date.parse(listing.listDate)) / (1000 * 60 * 60 * 24));
    flag &= filters.soldInLast >= parseInt((Date.now() - Date.parse(listing.soldDate)) / (1000 * 60 * 60 * 24));

    flag &= filters.rooms.bed == 0 ? true : filters.rooms.bed >= (isEmpty(listing.numBedrooms) ? 0 : parseInt(listing.numBedrooms)) + (isEmpty(listing.numBedroomsPlus) ? 0 : parseInt(listing.numBedroomsPlus));
    flag &= filters.rooms.bath == 0 ? true : filters.rooms.bath >= (isEmpty(listing.numBathrooms) ? 0 : parseInt(listing.numBathrooms)) + (isEmpty(listing.numBathroomsPlus) ? 0 : parseInt(listing.numBathroomsPlus));
    flag &= filters.rooms.parking == 0 ? true : filters.rooms.parking >= (isEmpty(listing.numParkingSpaces) ? 0 : parseInt(listing.numParkingSpaces));
    flag &= filters.rooms.garage == 0 ? true : filters.rooms.garage >= (isEmpty(listing.numGarageSpaces) ? 0 : parseFloat(listing.numGarageSpaces));

    flag &= isEmpty(listing.sqft) || (filters.size.minSize == 200 && filters.size.maxSize == 5000) ? true : parseInt(filters.size.minSize) >= parseInt(listing.sqft.split("-"[1])) && parseInt(listing.sqft.split("-"[0])) >= parseInt(filters.size.maxSize);
    flag &= isEmpty(listing.maintenance) || (filters.condo.minCondo == 5 && filters.condo.maxCondo == 5000) ? true : (filters.condo.minCondo <= parseFloat(listing.maintenance)) && (parseFloat(listing.maintenance) <= filters.condo.maxCondo);

    console.log(listing.id);
    return flag;
  }

  getBadge(filters) {
    var badge = 0;

    if (filters.propertyType.allTypes) badge = badge + 1;
    if (filters.propertyType.detached) badge = badge + 1;
    if (filters.propertyType.semiDetached) badge = badge + 1;
    if (filters.propertyType.freeholdTown) badge = badge + 1;
    if (filters.propertyType.condoTown) badge = badge + 1;
    if (filters.propertyType.condoApartment) badge = badge + 1;
    if (filters.propertyType.duplex) badge = badge + 1;
    if (filters.propertyType.multiFamily) badge = badge + 1;
    if (filters.propertyType.land) badge = badge + 1;

    if (filters.price.minPrice > 50000) badge = badge + 1;
    if (filters.price.maxPrice < 5000000) badge = badge + 1;
    if (filters.daysOnMarket != 0) badge = badge + 1;
    if (filters.soldInLast != 60) badge = badge + 1;

    if (filters.rooms.bath > 0) badge = badge + 1;
    if (filters.rooms.bed > 0) badge = badge + 1;
    if (filters.rooms.garage > 0) badge = badge + 1;
    if (filters.rooms.parking > 0) badge = badge + 1;

    if (filters.size.minSize > 200) badge = badge + 1;
    if (filters.size.maxSize < 5000) badge = badge + 1;

    if (filters.age.minAge > 1) badge = badge + 1;
    if (filters.age.maxAge < 100) badge = badge + 1;

    if (filters.condo.minCondo > 5) badge = badge + 1;
    if (filters.condo.maxCondo < 5000) badge = badge + 1;

    return badge;
  }

  getMarkers(listings) {
    var results = {}
    for (let index = 0; index < listings.length; index++) {
      const listingOne = listings[index];
      var lastStatus = '';
      if (listingOne.lastStatus != 'Sld' && listingOne.lastStatus != 'Lsd') {
        lastStatus = 'For'
      } else {
        lastStatus = listingOne.lastStatus;
      }
      // const key = listingOne.latitude + '#' + listingOne.longitude;
      const key = global.region.latitudeDelta > 0.01 ? listingOne.latitude + '#' + listingOne.longitude : listingOne.streetNumber + listingOne.streetName + listingOne.streetSuffix + lastStatus;
      if (isEmpty(results[key])) results[key] = [];
      results[key].push(listingOne);
    }
    return Object.values(results);
  }

  getClusters(listings) {
    var results = {}
    for (let index = 0; index < listings.length; index++) {
      const listingOne = listings[index];
      const key = listingOne.mlsNumber;
      if (isEmpty(results[key])) results[key] = [];
      results[key].push(listingOne);
    }
    return Object.values(results);
  }
}

const MapStore = new Store();
export default MapStore;